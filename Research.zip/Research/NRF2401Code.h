#include "HardwareSerial.h"
#ifndef NRF2401_H
#define NRF2401_H
#include <SPI.h>

#include <RF24.h>
#include <nRF24L01.h>
#include <Arduino.h>

RF24 radio(7, 8);

class NRF2401Code {
private:

public:
  NRF2401Code(){}
  void init() {
    radio.begin();
    SPI.begin();         // Initiate  SPI bus
    Serial.begin(9600);
    Serial.print(radio.isChipConnected());
    radio.openWritingPipe(0xE7E7E7E7E7);
    radio.setPALevel(RF24_PA_MAX);
    radio.setDataRate(RF24_250KBPS);
    radio.stopListening();
  }
  void send(String message) {
    char charArray[message.length() + 1];
    message.toCharArray(charArray, message.length() + 1);
    radio.write(charArray, message.length() + 1);
  }
  void send(int message) {

  char charArray[2];
  sprintf(charArray, "%d", message);
  radio.write(&charArray, sizeof(charArray));
  }
};

#endif